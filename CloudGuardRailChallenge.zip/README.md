# Cloud Engineer Guardrail Challenge: Security Compliance

This is my project for Cloud Engineer Guardrail Challenge. I am working on a security check message queues with CloudFormation and Lambda function. Also addng GitHub Actions for CI/CD pipeline.

## File Structure

```
CloudGuardRailChallenge.zip 
├── README.md # This file with instructions 
├── template.yaml # CloudFormation template 
├── requirements.txt # Python packages needed
├── .yamllint.yml # Config for YAML linting
├── .github/ 
│   └── workflows/ 
│     └── ci.yml # GitHub Actions workflow
├── lambda_function/
│   └── lambda_function.py # Code for security checks
└── tests/
    └── test_lambda_function.py # Unit tests
```

## What This Does

This solution check if new message queues follow security rules:

1. Check if VPC endpoint exists
2. Check if encryption is on
3. Check if using customer key not AWS key
4. Check if has tags: Name, CreatedBy, CostCenter
5. Check if has dead-letter queue

If queue not follow rules, system send alert message.

## Process to test

### Prereq

- AWS CLI on your computer
- AWS permissions for CloudFormation, IAM, Lambda
- For GitHub Actions: repository secrets for AWS

### Follow steps

1. **Clone repository**

2. **Change parameters in template.yaml if needed**:
   - Python version
   - Memory size
   - Permission boundary ARN
   - Organization unit ID

3. **Deploy with AWS CLI (change ARNs)**:
   ```bash
   aws cloudformation deploy \
     --template-file template.yaml \
     --stack-name GuardrailStack \
     --parameter-overrides LambdaRuntime=python3.9 LambdaMemorySize=128 PermissionBoundaryARN=arn:aws:iam::123456789012:policy/YourPermissionBoundary OrganizationalUnit=ou-example \
     --capabilities CAPABILITY_NAMED_IAM
   ```

4. **Or use AWS Console**:
   - Go to CloudFormation
   - Create stack
   - Upload template.yaml
   - Fill parameters
   - Create

## How to Test

After deploy, you can test:

1. **Create bad queue** (will trigger alert):
```bash
aws sqs create-queue --queue-name test-bad-queue
```

2. **Check logs**:
```bash
aws logs filter-log-events --log-group-name /aws/lambda/SQSGuardrailFunction
```

3. **Create good queue** (no alert):
```bash
aws sqs create-queue \
  --queue-name test-good-queue \
  --attributes '{
    "KmsMasterKeyId": "<your-key-id>",
    "RedrivePolicy": "{\"deadLetterTargetArn\":\"<your-dlq-arn>\",\"maxReceiveCount\":5}"
  }' \
  --tags '{
    "Name": "TestQueue",
    "CreatedBy": "Me",
    "CostCenter": "CC123"
  }'
```

## Weekend Challenge

As required over the weekend, I modified it whenever I found the time. First make template, then Lambda function, then tests, and finally GitHub Actions.

Hard parts:
- Find how to check if key is customer-managed
- Make sure events trigger correctly
- Fix permission problems

I tested in my personal AWS account with good and bad queues.

## More Information

- Lambda has error handling
- Use permission boundary for security
- Can work for many accounts
- GitHub Actions check code and can deploy

## SecretCode: coder-salman-2025-DAB
