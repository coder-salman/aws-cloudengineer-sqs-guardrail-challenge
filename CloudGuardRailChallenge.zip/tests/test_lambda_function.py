import json
import unittest
import os
import sys
from unittest.mock import patch, MagicMock

# Add lambda function directory to path for importing
sys.path.append(os.path.join(os.path.dirname(__file__), '..', 'lambda_function'))
import lambda_function

class TestLambdaFunction(unittest.TestCase):
    """Test cases for SQS Guardrail Lambda function"""

    @patch.dict(os.environ, {'SNS_TOPIC_ARN': 'arn:aws:sns:us-east-1:123456789012:test-topic'})
    def setUp(self):
        """Set up test environment"""
        self.sample_event = {
            'detail': {
                'eventSource': 'sqs.amazonaws.com',
                'eventName': 'CreateQueue',
                'requestParameters': {
                    'queueName': 'test-queue'
                }
            }
        }
    
    @patch('lambda_function.sqs_client')
    def test_invalid_event(self, mock_sqs):
        """Test handling of invalid event without detail"""
        result = lambda_function.lambda_handler({}, {})
        self.assertEqual(result['statusCode'], 400)
        self.assertEqual(result['body'], 'Invalid event format')
    
    @patch('lambda_function.sqs_client')
    def test_missing_queue_name(self, mock_sqs):
        """Test handling of event without queue name"""
        event = {'detail': {'requestParameters': {}}}
        result = lambda_function.lambda_handler(event, {})
        self.assertEqual(result['statusCode'], 400)
        self.assertEqual(result['body'], 'Queue name not found')
    
    @patch('lambda_function.sqs_client')
    def test_queue_not_found(self, mock_sqs):
        """Test handling when queue is not found"""
        mock_sqs.get_queue_url.side_effect = Exception('Queue not found')
        result = lambda_function.lambda_handler(self.sample_event, {})
        self.assertEqual(result['statusCode'], 404)
        self.assertTrue('Queue not found' in result['body'])
    
    @patch('lambda_function.validate_queue')
    @patch('lambda_function.sqs_client')
    def test_compliant_queue(self, mock_sqs, mock_validate):
        """Test handling of a fully compliant queue"""
        # Mock get_queue_url response
        mock_sqs.get_queue_url.return_value = {
            'QueueUrl': 'https://sqs.us-east-1.amazonaws.com/123456789012/test-queue'
        }
        
        # Mock validation results - all passed
        mock_validate.return_value = {
            'vpc_endpoint_exists': True,
            'encryption_enabled': True,
            'using_cmk': True,
            'has_required_tags': True,
            'has_dlq_configured': True
        }
        
        result = lambda_function.lambda_handler(self.sample_event, {})
        
        self.assertEqual(result['statusCode'], 200)
        self.assertTrue(result['compliant'])
        
        # Verify no alert was sent (alert function is not called)
        # This would require additional mocking if implemented
    
    @patch('lambda_function.send_alert')
    @patch('lambda_function.validate_queue')
    @patch('lambda_function.sqs_client')
    def test_noncompliant_queue(self, mock_sqs, mock_validate, mock_send_alert):
        """Test handling of a non-compliant queue"""
        # Mock get_queue_url response
        mock_sqs.get_queue_url.return_value = {
            'QueueUrl': 'https://sqs.us-east-1.amazonaws.com/123456789012/test-queue'
        }
        
        # Mock validation results - some failed
        validation_results = {
            'vpc_endpoint_exists': True,
            'encryption_enabled': False,
            'using_cmk': False,
            'has_required_tags': True,
            'has_dlq_configured': False
        }
        mock_validate.return_value = validation_results
        
        result = lambda_function.lambda_handler(self.sample_event, {})
        
        self.assertEqual(result['statusCode'], 200)
        self.assertFalse(result['compliant'])
        
        # Verify alert was sent
        mock_send_alert.assert_called_once_with('test-queue', validation_results)
    
    @patch('lambda_function.kms_client')
    def test_check_is_customer_managed_key(self, mock_kms):
        """Test detection of customer-managed vs AWS-managed keys"""
        # Test AWS-managed key
        mock_kms.describe_key.return_value = {
            'KeyMetadata': {
                'Description': 'Default KMS key that protects my SQS messages when no other key is defined'
            }
        }
        result = lambda_function.check_is_customer_managed_key('aws-managed-key')
        self.assertFalse(result)
        
        # Test customer-managed key
        mock_kms.describe_key.return_value = {
            'KeyMetadata': {
                'Description': 'Customer-managed key for SQS encryption'
            }
        }
        result = lambda_function.check_is_customer_managed_key('customer-managed-key')
        self.assertTrue(result)
    
    @patch('lambda_function.sqs_client')
    def test_check_required_tags(self, mock_sqs):
        """Test detection of required tags"""
        # Test with all required tags
        mock_sqs.list_queue_tags.return_value = {
            'Tags': {
                'Name': 'TestQueue',
                'CreatedBy': 'TestUser',
                'CostCenter': 'CC123'
            }
        }
        result = lambda_function.check_required_tags('queue-url')
        self.assertTrue(result)
        
        # Test with missing tags
        mock_sqs.list_queue_tags.return_value = {
            'Tags': {
                'Name': 'TestQueue'
            }
        }
        result = lambda_function.check_required_tags('queue-url')
        self.assertFalse(result)

if __name__ == '__main__':
    unittest.main()